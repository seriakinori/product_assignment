考察に使用したf1-scoreやrecall、precisionなどClassification Reportの情報は以下に格納してあります。

【ベースラインモデル】
product_assignment\text\CNN_GRU_test_results.txt

【改善モデル】
product_assignment\text\Attention_GRU_test_results.txt